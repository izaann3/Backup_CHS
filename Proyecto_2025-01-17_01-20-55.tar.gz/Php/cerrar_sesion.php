<?php
session_start();
session_destroy();
header('Location: https://izeta3.com//index.php');
exit();
?>
