<samp>
  <b>
    Izeta3.com is a prototype in progress of my musical website, where you can listen to my songs, provide ratings and contact me.
  </b>
</samp>

<p align="center">
  <a href="https://izaann3.github.io">
    <img src="https://img.shields.io/badge/Enter%20to%20izeta3.com-FFFFFF?style=for-the-badge&logo=web&logoColor=black" alt="Enter to izeta3.com">
  </a>
</p>

<details>
<summary>
  <samp>
    <b>More Info</b>
  </samp>
</summary>
  
  ```python
# Copyright (c) 2024 Izeta3 . All rights reserved.
  ```

</details>
